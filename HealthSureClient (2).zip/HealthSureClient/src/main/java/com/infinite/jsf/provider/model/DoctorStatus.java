package com.infinite.jsf.provider.model;

public enum DoctorStatus {
ACTIVE,INACTIVE
}
