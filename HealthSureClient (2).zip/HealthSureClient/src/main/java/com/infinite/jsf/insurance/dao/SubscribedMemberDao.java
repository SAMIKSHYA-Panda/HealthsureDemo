package com.infinite.jsf.insurance.dao;

import com.infinite.jsf.insurance.model.SubscribedMember;

public interface SubscribedMemberDao {
    void addSubscribedMember(SubscribedMember member);
}