package com.infinite.jsf.provider.model;

public enum AppointmentStatus {
	PENDING,BOOKED,CANCELLED,COMPLETED
}
