package com.infinite.jsf.provider.model;

public enum LoginStatus {
	PENDING, APPROVED, REJECTED
}
