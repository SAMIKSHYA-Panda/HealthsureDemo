package com.infinite.jsf.pharmacy.model;

public class PharmacyOtp {

}
