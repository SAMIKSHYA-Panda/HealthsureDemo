package com.infinite.jsf.insurance.model;

public enum Status {
	ACTIVE, INACTIVE, BLOCKED
}
