package com.infinite.jsf.provider.model;

public class FamilyMember {

}
