package com.infinite.jsf.provider.model;

public enum ProviderStatus {
PENDING,APPROVED,REJECTED
}
