package com.infinite.jsf.recipient.model;

public enum Gender {
	Male,Female;
}
