package com.infinite.jsf.insurance.model;

public enum RelationWithProposer {
    Self,
    Spouse,
    Child,
    Parent
}
