package com.infinite.jsf.provider.model;

public enum SlotType {
STANDARD,ADCHOC
}
