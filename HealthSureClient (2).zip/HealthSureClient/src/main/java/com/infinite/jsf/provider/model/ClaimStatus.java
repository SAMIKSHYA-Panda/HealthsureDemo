package com.infinite.jsf.provider.model;

public enum ClaimStatus {
PENDING,APPROVED,DENIED
}
