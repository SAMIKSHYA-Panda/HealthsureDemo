package com.infinite.jsf.insurance.model;

public enum OtpStatus {
	PENDING, VERIFIED, EXPIRED;
}
