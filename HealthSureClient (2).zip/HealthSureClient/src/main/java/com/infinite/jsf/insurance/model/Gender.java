package com.infinite.jsf.insurance.model;

public enum Gender {
	 MALE, FEMALE;
}
