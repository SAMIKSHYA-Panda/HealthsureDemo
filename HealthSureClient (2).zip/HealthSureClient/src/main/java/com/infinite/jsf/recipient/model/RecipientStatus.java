package com.infinite.jsf.recipient.model;

public enum RecipientStatus {
	ACTIVE, INACTIVE, BLOCKED
}
